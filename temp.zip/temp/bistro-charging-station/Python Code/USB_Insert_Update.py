import serial
import os
import time
import struct

from threading import Timer
from time import sleep
import MySQLdb


#open usb port 
ser = serial.Serial(port = '/dev/tty.usbserial-A9OFB9T9', baudrate = 57600, bytesize=8, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,)
print "Start!"
#helper function to process input
def process(str):
    dataList = []
    for ele in str.split(';'):
        data = ele.split(':')[1][0:4]
        dataList.append(float(data))

    return dataList

#gets the next line from usb port and updates plot.
def collect_data():
    global prev_time
    global ser
    
    d = ser.readline()
    data= process(d)		
    ser.flushInput()

    return data

#connect to the database
mydb = MySQLdb.connect(host='140.232.220.200',user='admin',passwd='energy!',db='Agosta_Micgrid')
cursor = mydb.cursor()

insertQuery = """INSERT INTO USB VALUES (%s, %s, %s, %s, %s, %s, %s)"""  # change SYS to the table name you have
updateQuery = """UPDATE USB_Single SET USB1=%s, USB2=%s, USB3=%s, USB4=%s, USB5=%s, USB6=%s, USB7=%s, USB8=%s, TIME=%s, Local_Time=%s WHERE ID=%s"""

#calls the program (can only quit using keyboard escape!)
prev_time = time.time()
ct = 63
while True:
    now_time = time.time()
    if now_time - prev_time >= 10:
        prev_time = now_time
        print 'collectdata'
        data = collect_data()
        dataList = [data[0],data[1],data[2],data[3],data[4],data[5],data[6],data[7],now_time,ct]
        print dataList
        cursor.execute(insertQuery, dataList)
        print "insert data:",dataList
        dataList.append(0)
        print "update data:",dataList
        cursor.execute(updateQuery, dataList)
        mydb.commit()
        print "data is updated at:",ct


