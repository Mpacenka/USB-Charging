import serial
import matplotlib
import os
import time
import struct
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as anim

prev_time = time.time()

#open usb port 
ser = serial.Serial(port = '/dev/tty.usbserial-A9OFB9T9', baudrate = 57600, bytesize=8, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,)

verbose = True #set to True to print extra information to terminal

try: 
	ser.open()
except Exception, e:
	if not 'already open.' in str(e):
		if verbose:
			print str(e)
		exit()
	else:
		if verbose:
			print str(e)

#helper function to process input
def process(str):
	strs = []
	if verbose:
		print str
	for s in str.split(';'):
		splt = s.split(':')[1]
		if '\n' in splt:
			strs.append(float(splt[:-2]))
		else:
			strs.append(float(splt[:-1]))
	return strs

#initialize bar plot and data structures needed
print "bird2"
data = [[]]*2
bar_width= .5
ind = np.arange(8)

#bar graph plotting:
print "bird2"

data[0]=['#1','#2','#3','#4','#5','#6','#7','#8']

saved_power = 15


count = 0
#...saving the data
namebase = str(time.strftime("%d-%m-%Y"))+'.txt'
name1 = namebase
name2 = 'currentMeas.txt'
name3 = os.getcwd()
print  name3
file = open(name1, 'w')
file2 = open(name2, 'w')
file.write(str(data[0])[1:-1]+'\n')
print str(data[0])

def update_power(new_data):
	global saved_power_file
	saved_power_file = open('saved_power')
	saved_powers = saved_power_file.readline()
	saved_power = float(saved_powers)
	saved_power_file = open('saved_power','w')
	saved_power_file.write(str(saved_power + sum(new_data)*5)) #since it's a 5 volt system. 
	print saved_power
	return saved_power

#gets the next line from usb port and updates plot.
def collect_and_plot():
	global prev_time
	global count
	global file
	global txt
	while True:
		count+=1
	        d = ser.readline()
		data[1]= process(d)
		update_power(data[1])
		#Write current data to file
		file2 = open(name2, 'w')
		file2.write(str(data[0])[1:-1]+'\n'+str(data[1])[1:-1]+'\n')
		if time.time()-prev_time >= 86400:
			prev_time = time.time()
			name = str(time.strftime("%d-%m-%Y"))+'.txt'
			print name
			with open(name, 'w') as f:
				file = f
		else:
			if count==5:#records every 5 data points in 'data' directory files
				count = 0
				file.write(str(data[1])[1:-1]+'\n')
		
		
		ser.flushInput()

#calls the program (can only quit using keyboard escape!)
collect_and_plot()
