import mysql.connector

config = {
  'user': 'root',
  'password': 'root',
  'host': 'localhost:8889',
  'database': 'MicroGridLab',
  'raise_on_warnings': True,
}

link = mysql.connector.connect(**config)
