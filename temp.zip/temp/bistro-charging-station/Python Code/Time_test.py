# time
import os, time
now_time = time.ctime()
print now_time
m = now_time.split(' ')
year = m[4]
day = m[1]+m[2]
print year,day

path = '/Users/microgridlab/Data/2016/Mar21/PowCrv.001'
path = r'/Users/microgridlab/Data/'+year+'/'+day+'/PowCrv.001'
print path
file = open(path,"r")
file.seek(-153,2)
line = file.readline()
data =line.split('\t')
print data

file.close()


