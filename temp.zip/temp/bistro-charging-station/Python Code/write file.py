import os,time
for i in range(100):
    
    path = r'/Users/microgridlab/Desktop/test'
    file = open(path,"w")
    file.write("line: "+ str(i))
    file.close()
    print time.time(),'the index is ',i
    time.sleep(10)

    

