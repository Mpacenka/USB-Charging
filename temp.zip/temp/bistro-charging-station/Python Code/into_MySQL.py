#into MySQL database
import MySQLdb
mydb = MySQLdb.connect(host='localhost',user='root',passwd='energy',db='sys')
cursor = mydb.cursor()

query = """INSERT INTO USB_chargers VALUES (%s, %s, %s, %s, %s, %s, %s, %s,%s)"""

values = (0,0,0,0,0,0,0,1.1,"123210")
cursor.execute(query, values)
mydb.commit()
cursor.close()

