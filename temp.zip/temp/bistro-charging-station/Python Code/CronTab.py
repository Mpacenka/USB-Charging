#CronTab Setup

#Time restrictions

#python crontab download -->
#https://pypi.python.org/pypi/python-crontab/

#https://www.youtube.com/watch?v=iyv1iySErc0

#Celery??

#from celery.task import tasks, PeriodicTask
##>>> from datetime import timedelta
##>>> class EveryThirtySecondsTask(PeriodicTask):
##...     run_every = timedelta(seconds=30)
##...
##...     def run(self, **kwargs):
##...         logger = self.get_logger(**kwargs)
##...         logger.info("Execute every 30 seconds"
##
##import schedule
##import time
##from datetime import datetime
##
##def job():
##    #append data to file
##    #check for new data
##    #add new data
##    #repeat

schedule.every().minute.do(job)
schedule.every().hour.do(job)
schedule.every().day.at("date").do(job)
schedule.every(30).seconds.do(job)

while 1:
    schedule.run_pending()
    time.sleep(seconds)

