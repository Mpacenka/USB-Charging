#read the file
path = r'/Users/microgridlab/Data/2016/Mar25/PowCrv.003'

file = open(path,"r")
m = file.read()
print m
file.close()
