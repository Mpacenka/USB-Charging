#UPLOAD real time random data to localhost mysql database
import lib2to3
import os
import time
import struct
import random

from threading import Timer
from time import sleep
import MySQLdb  #you need to install mySQLdb libaray,installer is attached

#empty_cron = CronTab()
#my_user_cron = CronTab(User = True)
#users_cron = CronTab(user = 'username')

#job = cron.new(command = '/usr/bin/echo')

#job.second.every(30)
#or is it
#job.minute.every(.5)


#connect to the database
mydb = MySQLdb.connect(host='140.232.220.200',user='admin',passwd='energy!',db='Agosta_Micgrid') # change user,passwd,database name
cursor = mydb.cursor()

insertQuery = """INSERT INTO SYS VALUES (%s, %s, %s, %s, %s, %s,%s)"""  # change SYS to the table name you have
updateQuery = """UPDATE SYS_Single SET PV_V=%s,PV_C=%s,OUT_V=%s,OUT_C=%s,BAT_V=%s,TIME=%s,Local_Time=%s WHERE ID =%s"""


pre_time = time.time()

pre_line =''
while True:
    now_time = time.time()
    if now_time - pre_time >=60:
        pre_time = now_time

        path = r'/Users/microgridlab/Data/Oneline.txt'
        file = open(path,'r')
        txt = file.readline()
        line = txt.split('\n')[0]
        data = line.split('\t')
        file.close()
        
        pv_v = float(data[0])
        pv_c = float(data[1])
        out_v = float(data[3])
        out_c = float(data[4])
        bat_v = float(data[6])

        dataList = [pv_v,pv_c,out_v,out_c,bat_v]
        ct = float(data[10])
        
        if line == pre_line:
            dataList =[-999,-999,-999,-999,-999]# -999 is Nodata type
            dataList.append(now_time)
            dataList.append(ct)
            print ("Data is not updated!!!!")

        else:
            dataList.append(now_time)
            dataList.append(ct)

        pre_line = line
        cursor.execute(insertQuery, dataList)
        print ("insert data:",dataList)
        dataList.append(0)
        print ("update data:",dataList)
        cursor.execute(updateQuery, dataList)
        mydb.commit()
        print ("data is updated at:",ct)
