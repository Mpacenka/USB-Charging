# time
import os, time
m =0
prev_time = time.time()
while True:

    now_time = time.time()
    if now_time - prev_time >=10:
        prev_time = now_time
        
        path = r'/Users/microgridlab/Data/Oneline.txt'
            
        file = open(path,"r")

        txt = file.readline()
        line = txt.split("\n")[0]
        data =line.split('\t')
        print data
        file.close()
        print "loop"

#                lines = file.readlines()
#                line = lines[-1]
#                data = line.split('\t')
#                print data
#                del lines
#                file.close()

                
#            except:
#                print "No data extracted!"
#                file.close()
#                continue





