#test code for read the file
import os,time

while True:
    path = r'/Users/microgridlab/Desktop/test'
    file = open(path,"r")
    file.seek(-8,os.SEEK_END)
    m = file.readlines()[-1]
    print m
    file.close()

    time.sleep(10)
