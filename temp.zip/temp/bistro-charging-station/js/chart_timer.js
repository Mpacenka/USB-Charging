/*$(function() {

        
        var data = [];
         //res=[];
            //totalPoints = 300;

        function getTableData() {

            $.ajax({
                url: "php/query1.php",
                type: "GET",
                dataType: "json",
                success: function (response){
                    for(var i=0; i<60; ++i){
                        if (response[i] ==-999){
                            data[i]=0
                        } else {
                            data[i]= (Number(response[i]))
                        }
                        
                    }
                    //querydata=response;
                                      
                }
            });
            console.log('Query',data[0])
            var res = [];
            //var head=data.length-30;
            for (var i = 0; i < data.length; ++i) {
                res.push([i, data[i]])
            }
            return res;

        }
        

        // Set up the control widget

        var updateInterval = 6000;
        
        var timenow = Date.now();

        var plot = $.plot("#chart_div", [ getTableData() ], {
            series: {
                shadowSize: 0   // Drawing is faster without shadows
            },
            yaxis: {
                min: 0,
                max: 150
            },
            xaxis: {
                show: true,

                //mode: "time",
                min: 0,
                max: 60 ,
            },
        });
        function update() {

            plot.setData([getTableData()]);

            // Since the axes don't change, we don't need to call plot.setupGrid()

            plot.draw();
            setTimeout(update, updateInterval);
            console.log('data',data)
            //console.log('res',res)
        }

        update();
    });
*/