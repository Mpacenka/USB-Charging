      // Bistro Charging Station
    
      google.charts.load('current', {'packages':['corechart', 'gauge', 'bar', 'line']});
      //google.charts.setOnLoadCallback(drawgauChart);
      google.charts.setOnLoadCallback(drawbarChart);
      google.charts.setOnLoadCallback(drawbarChartTwo);
      google.charts.setOnLoadCallback(drawBasic);

//GAUGE CHART
      /*function drawgauChart() {

        var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          ['Status', 0],
          
        ]);

        var options = {
          
          redFrom: 0, redTo: 0.3,
          yellowFrom:0.3, yellowTo: 0.6,
          greenFrom: 0.60, greenTo: 1,
          max: 1,
          min: 0
          
          
        };

        var chart = new google.visualization.Gauge(document.getElementById('gauchart_div'));
            
        
        chart.draw(data, options);

        setInterval(function() {
          $.ajax({
            url: "php/query_sys.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {

              var PV_V = Number(response['PV_V']);
              var PV_C = Number(response['PV_C']);
              var Power = PV_V*PV_C 
              //console.log(PV_V);
              PV_V=PV_V/70;
              if (PV_V<0) {
                PV_V= 0;
              } else if (PV_V>1) {
                PV_V=1;
              } 
              data.setValue(0, 1, PV_V);
              chart.draw(data, options);

            }
        });
          
        }, 1000);
        
      };*/
      
//PARAMETERS BAR CHART
      function drawbarChart() {
        var data = new google.visualization.arrayToDataTable([
          ['', 'Voltage', 'Current'],
          ['PV', 80, 23.3],
          ['Output', 24, 4.5],
          ['Battery', 23, 0],
        ]);

        var options = {
          
          chart: {
            title: 'PARAMETERS',
            
          },
          bars: 'horizontal', 
          series: {
            0: { axis: 'voltage' }, 
            1: { axis: 'current' } 
          },
          axes: {
            x: {
              current: {label: 'ampere(A)'}, // Bottom x-axis.
              voltage: {side: 'top', label: 'volt(V)'} // Top x-axis.
            }
          }
        };
      //php_url
      var chart = new google.charts.Bar(document.getElementById('barchart_div'));
      chart.draw(data, options);
      setInterval(function() {
          $.ajax({
            url: "php/query_sys.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {

              var PV_V = Number(response['PV_V']);
              var PV_C = Number(response['PV_C']);
              var OUT_V = Number(response['OUT_V']);
              var OUT_C = Number(response['OUT_C']);
              var BAT_V = Number(response['BAT_V']);
              if (PV_V<0) { PV_V= 0;
              }
              if (PV_C<0) { PV_C= 0;
              }
              if (OUT_V<0) { OUT_V= 0;
              }
              if (OUT_C<0) { OUT_C= 0;
              }
              if (BAT_V<0) { BAT_V= 0;
              }
              /*console.log(PV_V);
              console.log(PV_C);
              console.log(OUT_V);
              console.log(OUT_C);
              console.log(BAT_V);
              
              data.setValue(0, 1, PV_V);
              data.setValue(0, 2, PV_C);
              data.setValue(1, 1, OUT_V);
              data.setValue(1, 2, OUT_C);
              data.setValue(2, 1, BAT_V);
              chart.draw(data, options);

            }
        });
          
        }, 1000);
    };*/
    
    
 //BATTERY CHARGE BAR GRAPH   
 /*   function drawbarChart() {
        var data = new google.visualization.arrayToDataTable([
          ['', 'Grid','Battery'],
          ['Power (W)', 10,5],
        ]);
 var options = { 
	            series:{
    			0:{color: 'blue'},
    		    1:{color: 'red'},
    		//	2:{color: 'orange'}
    			},
          	legend: {position: 'top',  textStyle:{color: 'blue', fontSize: 14}},
           //legend: { position:'none', },
           chartArea:{left:30,top:20,width:160,height:'80%'},
           bar:{groupWidth: 60},
            vAxis: {
            	     maxValue: 50,
                 //    gridlines:{ count: 8}
                    },
          	width: 200,
          	heignt: 450,
          	isStacked: true,
       	 };
       	 
     	var chart = new google.visualization.ColumnChart(document.getElementById('Battery_Charge'));
     	chart.draw(data, options);
      	setInterval(function() {
          $.ajax({
            url: "php/query_sys.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {

              var BAT_V = Number(response['BAT_V']);
	  	//  console.log('Bat Volts', BAT_V);
			document.getElementById('footerdata').innerHTML= "Battery Voltage = " + BAT_V.toFixed(1);
              
              data.setValue(0, 1, gridPow);
              data.setValue(0, 2, batPow);
          //    data.setValue(0, 3, solPow);
              chart.draw(data, options);

            }
        });
          
        }, 10000);
    };               */
    
//TOTAL ENERGY PRODUCED BAR GRAPH  
 /* function drawbarChartTwo() {
        var data = new google.visualization.arrayToDataTable([
          ['', 'Energy (kWh)'],
          ['Energy (kWh)', 2],
        ]);
        
        var options = {
          bars: 'vertical',  
          legend: { position:'none'},
   
          vAxis: {viewWindow: {max: 8}},
          chartArea: {height: 150},
          width: 100,
          heignt: 300,
        };
     	var chart = new google.charts.Bar(document.getElementById('Total_Energy_Chart'));
     	chart.draw(data, google.charts.Bar.convertOptions(options));
        setInterval(function() {
                //  wattHours = 3500;
              data.setValue(0, 1, wattHours/1000);
              chart.draw(data, google.charts.Bar.convertOptions(options));
           
        }, 10000);
    };             */

  
//php_url    
//IS SYSTEM RUNNING 
setInterval(function() {
    $.ajax({
    url: 'php/query_sys.php',
    dataType: 'json',
    type: "GET",
    success: function (response) 
       {

        var BAT_V = Number(response['BAT_V']);
		var status = document.getElementById('system_status')
    	if (BAT_V>42.0)  // perameters for bistro system??
			{
			status.innerHTML = "The sun is up and the system is ready to charge your phones!";
			document.getElementById('system_status').style.background = "#F0F48A";
			}
        else 
			{
			status.innerHTML = "Looks like its pretty cloudy, the system can't charge your phones! Sorry ):";
			document.getElementById('system_status').style.background = "#C0C0C0";
			}  
       } 
   });
          
}, 10000); 
  
  var wattHours = 0;
  var OPWh = 0;
  var solOutWh = 0;
  var batOutWh = 0;
  var gridOutWh = 0;
  var batPow = 0;
  var gridPow = 0;
  var solPow = 0 ;


//PV POWER GRAPH
function drawBasic() {
	
	var oldPoints = 0;
	var plotdata = new google.visualization.DataTable();
		plotdata.addColumn('timeofday', 'Time');
		plotdata.addColumn('number', 'Solar');
		
//	var plotdataB = new google.visualization.DataTable();
//	  plotdataB.addColumn('timeofday', 'Time');
//		plotdataB.addColumn('number', 'Grid');
//		plotdataB.addColumn('number', 'Solar');
//		plotdataB.addColumn('number', 'Battery');	
				
				
    var options = {
    	isStacked: false,
    	legend: {position: 'top', textStyle:{color: 'blue', fontSize: 10}},
    	series:{
    			0:{color: '08BD13'},
    			// 1:{color: '06740D'},
    			// 2:{color: 'orange'}
    			},
        hAxis: {
          title: 'Time',
          viewWindowMode: 'explicit',
          viewWindow:{ min:0, },
          gridlines:{
          	count: 12,
          }
        },
        vAxis: {
          title: 'Power (watts)',
          viewWindowMode: 'explicit',
          viewWindow:{
          	min:0,
          },
          gridlines:{
          	count:11,
          }
        }, 
        
		chartArea:{
        	left: 70,
        	top: 30,
        	width: 800,
        	height: 230,
        }
    }   	
    
       var optionsB = {
    	isStacked: true,
    	legend: {position: 'top', textStyle:{color: 'blue', fontSize: 14}},
    	series:{
    			0:{color: 'blue'},
    			1:{color: 'orange'},
    			2:{color: 'red'}
 
    			},
        hAxis: {
          title: 'Time',
          format: 'h:mm a',
          viewWindowMode: 'explicit',
          viewWindow:{ min:0, },
   //       gridlines:{
    //      	count: 12,
     //     }
        },
        vAxis: {
          title: 'Power (watts)',
          viewWindowMode: 'explicit',
          viewWindow:{
          	min:0,
          },
     //     gridlines:{
      //    	count:11,
      //    }
        }, 
        
		chartArea:{
        	left: 70,
        	top: 30,
        	width: 800,
        	height: 180,
        }   
    }   	
	var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
      	chart.draw(plotdata, options);
	var chart2 = new google.visualization.AreaChart(document.getElementById('chart_div2'));
      	chart2.draw(plotdataB, optionsB);
        setInterval(function() {
          $.ajax({
            url: "php/query1.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {		
				var PV_Cary = [0.1, 0.2, 0.3]
				var PV_Vary = response.map(function (x) {return Number(x[0])});
				var PV_Cary = response.map(function (x) {return Number(x[1])});
				var Local_Time = response.map(function (x) {return Number(x[6])});
				var WPowerA = response.map(function (x) {return Number(x[8])});
				var OPower = response.map(function (x) {return Number(x[2])});
				var BPower = response.map(function (x) {return Number(x[3])});    // Battery Power
				var GPower = response.map(function (x) {return Number(x[9])});    // Grid Power
				var LVTime = response.map(function (x) {return Number(x[5])});
				var WPowerB = response.map(function (x) {return Number(x[10])});


				//console.log("big lunch");
            	points = PV_Vary.length;
            	var index = points-1;
            	console.log(points);
            	var SPower = [0.1, 0.2, 0.3];
            	var SPowerOut = [0.1, 0.2, 0.3];
            	var GPowerOut = [0.1, 0.2, 0.3];
            	var BPowerOut = [0.1, 0.2, 0.3];
            	var d = new Date();
            	var tim = "time";
            	var delt = 0;
            	//console.log('Timed', d);
            	
            // Need to clean out	
            	if (oldPoints == 0)
            	        {
            	          for(var i=0; i<points; i++)
            	                   {
            	   	                 d = new Date(LVTime[i]*1000);
            	   	                 hour = d.getUTCHours();   
            	   	                 hour = hour - 5;
            	   	                 if (hour < 0) hour += 24;
            	   	                 minutes = d.getMinutes();
            	   	                 seconds = d.getSeconds();
            	   	                 if (PV_Vary[i]<0) { PV_Vary[i]= 0;}
              	                     if (PV_Cary[i]<0) { PV_Cary[i]= 0;}
              	                     if (OPower[i]<0) { OPower[i]= 0;}
                                     SPower[i] = PV_Vary[i]*PV_Cary[i];
                                     if (OPower[i]>SPower[i])
                                     	{SPowerOut[i] = SPower[i];}
                                     else
                                        {SPowerOut[i] = OPower[i];}
                                        
                                     if (GPower[i] > 0)
                                        {GPowerOut[i] = 0;}   
                                     else
                                        {GPowerOut[i] = -GPower[i];}
                                        
                                     if (BPower[i] < 0)
                                     	{BPowerOut[i] = 0;}
                                     else
                                     	{BPowerOut[i] = BPower[i];}   	

                                     if (i>0)
                                         {
                                          delt = (LVTime[index]-LVTime[index-1])/3600;
                                          wattHours += SPower[i]*delt;
                                          batOutWh += BPowerOut[i]*delt;
                                          solOutWh += SPowerOut[i]*delt;
                                          OPWh += OPower[i]*delt;
                                          gridOutWh += GPowerOut[i]*delt;
                                         } 
                                     plotdata.addRows([[[hour, minutes, seconds], WPowerA[i], WPowerB[i], SPower[i]]]);
                                     plotdataB.addRows([[[hour, minutes, seconds], GPowerOut[i], SPowerOut[i], BPowerOut[i] ]]);
                                       
                                    }
                           } 
                // Need to clean out          
                if (points > oldPoints) 
                	    {
                	    //console.log('points', points);
                	    //console.log('oldPoints', oldPoints);
                	    d = new Date(LVTime[index]*1000);
            	   	    hour = d.getUTCHours();
            	   	    //console.log('hour', hour);
            	   	    hour = hour - 5;
            	   	    if (hour < 0) hour += 24;
            	   	    //console.log('hour', hour);
            	   	    minutes = d.getMinutes();
            	   	    seconds = d.getSeconds();
                        if (PV_Vary[index]<0) { PV_Vary[index]= 0;}
              	        if (PV_Cary[index]<0) { PV_Cary[index]= 0;}
              	        if (OPower[index]<0) { OPower[index]= 0;}
                        SPower[index] = PV_Vary[index]*PV_Cary[index];
                        wattHours += SPower[index]*(Local_Time[index]-Local_Time[index-1]); 
                        if (OPower[index]>SPower[index])
                            {SPowerOut[index] = SPower[index];}
                        else
                            {SPowerOut[index] = OPower[index];}	
                            
                        if (GPower[index] > 0)
                            {GPowerOut[index] = 0;}   
                        else
                            {GPowerOut[index] = -GPower[index];}
                            
                        if (BPower[index] < 0)
                            {BPowerOut[index] = 0;}
                        else
                            {BPowerOut[index] = BPower[index];}  
                                     	    	
                        //console.log('GPowerout', GPowerOut[index]);
                        // console.log('WPower', WPowerA[index]);
                        //console.log('SPower', SPower[index]);
                        // console.log('SPowerOut', SPowerOut[index]);
                        //console.log('BPower', BPower[index]);
                        //console.log('OPower', OPower[index]);
                        //console.log('time', Local_Time[index]);
                        //console.log('wattHours', wattHours);
                        if (index>0)
							 {
							  delt = (LVTime[index]-LVTime[index-1])/3600;
							  wattHours += SPower[index]*delt;
							  batOutWh += BPowerOut[index]*delt;
							  solOutWh += SPowerOut[index]*delt;
							  OPWh += OPower[index]*delt;
							  gridOutWh += GPowerOut[index]*delt;
							 } 
                        plotdata.addRows([[[hour, minutes, seconds], WPowerA[index], WPowerB[index], SPower[index]]]); 
                        plotdataB.addRows([[[hour, minutes, seconds], GPowerOut[index], SPowerOut[index], BPowerOut[index] ]]); 
                        }   
                      
              	oldPoints = points;
              	
              	if (BPower[index] > 0)
                    {batPow = 2;}
                else
                    {batPow = -BPower[index];}  
                    
              	if (GPower[index] > 0)
                    {gridPow = GPower[index];}
                else
                    {gridPow =2;} 
                                         
              	solPow = SPower[index];
              	//batPow = 20;
              	//gridPow = 10;
              	//solPow = 30;
              	//console.log(wattHours);
              	//console.log(PV_Vary);
              	//console.log(PV_Cary);
              	//console.log(Local_Time);
              
				chart.draw(plotdata, options);  
				chart2.draw(plotdataB, optionsB);         
				
				var renewFrac = 0.5+100*(solOutWh+batOutWh)/(solOutWh+batOutWh+gridOutWh);
				var carbSave = 1.22*wattHours/1000;
				//console.log('gridOutWh',gridOutWh);
				//console.log('renewFrac',renewFrac);

                document.getElementById('renewparam').innerHTML= "Today " + renewFrac.toFixed(0) + "%<br />" +
               "This Week " + renewFrac.toFixed(0) + "%";
                document.getElementById('carbparam').innerHTML= "Today " + carbSave.toFixed(1) + " lbs<br />" +
               "This Week " + carbSave.toFixed(1) + " lbs";
      		}
      	  })
      	}, 10000);
};

/* var chart = new google.visualization.AreaChart(document.getElementById('chart_div')); */

/* Information Station */
 /* var text_box = google.visualization(var plug)
  setInterval function()
    var tim = "time";
    if (var tim <= 2000)
        var plug = {.innerHTML= "Divest Clark Message"}
    if (2001 < var tim < 4000)
        var plug = {.innerHTML= "Sustainability Initiative Plug"}
    else
        var plug = {.innterHTML= "The graph above shows the amount of power we are able to get from our solar panels on the roof with the amount of sun that is out right now"}
      */
   
