      google.charts.load('current', {'packages':['corechart', 'gauge', 'bar', 'line']});
      //google.charts.setOnLoadCallback(drawgauChart);
      google.charts.setOnLoadCallback(drawbarChart);
      google.charts.setOnLoadCallback(drawbarChartTwo);
      google.charts.setOnLoadCallback(drawBasic);

//GAUGE CHART
      /*function drawgauChart() {

        var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          ['Status', 0],
          
        ]);

        var options = {
          
          redFrom: 0, redTo: 0.3,
          yellowFrom:0.3, yellowTo: 0.6,
          greenFrom: 0.60, greenTo: 1,
          max: 1,
          min: 0
          
          
        };

        var chart = new google.visualization.Gauge(document.getElementById('gauchart_div'));
            
        
        chart.draw(data, options);

        setInterval(function() {
          $.ajax({
            url: "php/query_sys.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {

              var PV_V = Number(response['PV_V']);
              var PV_C = Number(response['PV_C']);
              var Power = PV_V*PV_C 
              //console.log(PV_V);
              PV_V=PV_V/70;
              if (PV_V<0) {
                PV_V= 0;
              } else if (PV_V>1) {
                PV_V=1;
              } 
              data.setValue(0, 1, PV_V);
              chart.draw(data, options);

            }
        });
          
        }, 1000);
        
      };*/
      
//PARAMETERS BAR CHART
 /*     function drawbarChart() {
        var data = new google.visualization.arrayToDataTable([
          ['', 'Voltage', 'Current'],
          ['PV', 80, 23.3],
          ['Output', 24, 4.5],
          ['Battery', 23, 0],
        ]);

        var options = {
          
          chart: {
            title: 'PARAMETERS',
            
          },
          bars: 'horizontal', 
          series: {
            0: { axis: 'voltage' }, 
            1: { axis: 'current' } 
          },
          axes: {
            x: {
              current: {label: 'ampere(A)'}, // Bottom x-axis.
              voltage: {side: 'top', label: 'volt(V)'} // Top x-axis.
            }
          }
        };

      var chart = new google.charts.Bar(document.getElementById('barchart_div'));
      chart.draw(data, options);
      setInterval(function() {
          $.ajax({
            url: "php/query_sys.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {

              var PV_V = Number(response['PV_V']);
              var PV_C = Number(response['PV_C']);
              var OUT_V = Number(response['OUT_V']);
              var OUT_C = Number(response['OUT_C']);
              var BAT_V = Number(response['BAT_V']);
              if (PV_V<0) { PV_V= 0;
              }
              if (PV_C<0) { PV_C= 0;
              }
              if (OUT_V<0) { OUT_V= 0;
              }
              if (OUT_C<0) { OUT_C= 0;
              }
              if (BAT_V<0) { BAT_V= 0;
              }
              /*console.log(PV_V);
              console.log(PV_C);
              console.log(OUT_V);
              console.log(OUT_C);
              console.log(BAT_V);
              
              data.setValue(0, 1, PV_V);
              data.setValue(0, 2, PV_C);
              data.setValue(1, 1, OUT_V);
              data.setValue(1, 2, OUT_C);
              data.setValue(2, 1, BAT_V);
              chart.draw(data, options);

            }
        });
          
        }, 1000);
    };*/
    
    
 //BATTERY CHARGE BAR GRAPH   
    function drawbarChart() {
        var data = new google.visualization.arrayToDataTable([
          ['', 'Percent Charged'],
          ['Percent Charged', 100],
        ]);
		var options = {
          bars: 'verticle', 
          legend: {
          	position:'none', 
          },
          width: 200,
          heignt: 400,
          vAxis: {
          	viewWindowMode: 'explicit',
          	viewWindow:{
          		min:0,
          		max:100,
          	},
          	gridlines:{
          		count:5,
          	}
          },
        };
     	var chart = new google.charts.Bar(document.getElementById('Battery_Charge'));
     	chart.draw(data, options);
      	setInterval(function() {
          $.ajax({
            url: "php/query_sys.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {

              var BAT_V = Number(response['BAT_V']);
              BAT_V = (BAT_V-24)*100/(4);
              if (BAT_V<0) { BAT_V= 0;
              }
              else if (BAT_V>100) { BAT_V = 100;
              }
              var Voltage = BAT_V;
              
              data.setValue(0, 1, BAT_V);
              chart.draw(data, options);

            }
        });
          
        }, 1000);
    };
    
//TOTAL ENERGY PRODUCED BAR GRAPH  
  function drawbarChartTwo() {
        var data = new google.visualization.arrayToDataTable([
          ['', 'Energy Produced (Wh)'],
          ['Energy Produced (Wh)', 100],
        ]);
		var options = {
          bars: 'verticle',  
          legend: {
          	position:'none', 
          },
          width: 200,
          heignt: 400,
        };
     	var chart = new google.charts.Bar(document.getElementById('Total_Energy_Chart'));
     	chart.draw(data, options);
      	setInterval(function() {
          $.ajax({
            url: "php/query_sys.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {

              var PV_V = Number(response['PV_V']);
              var PV_C = Number(response['PV_C']);
              var Local_Time = Number(response['Local_Time']);
              if (PV_V<0) {PV_V= 0;
              }
              else if (PV_C<0) {PV_C = 100;
              }
              var Power = PV_V*PV_C             
              data.setValue(0, 1, Power);
              chart.draw(data, options);
            }
        });
          
        }, 1000);
    };  

  
    
//IS SYSTEM RUNNING 
setInterval(function() {
    $.ajax({
    url: "php/query_sys.php",
    dataType: 'json',
    type: "GET",
    success: function (response) {

        var BAT_V = Number(response['BAT_V']);
		var status = document.getElementById('system_status')
    	if (BAT_V>24.7){
        status.innerHTML = "SYSTEM IS RUNNING";
        document.getElementById('system_status').style.background = "#1ACD86";
        }
        else {
        status.innerHTML = "SYSTEM IS NOT RUNNING";
        document.getElementById('system_status').style.background = "#C33";
        }  
 } 
});
          
}, 1000); 
   
//PV POWER GRAPH
function drawBasic() {

	var data = new google.visualization.DataTable();
		data.addColumn('number', 'Time');
		data.addColumn('number', 'Power');
		
		
    var options = {
        hAxis: {
          title: 'Time (Hours)',
          viewWindowMode: 'explicit',
          viewWindow:{
          	min:0,
          },
          gridlines:{
          	count: 12,
          }
        },
        vAxis: {
          title: 'Solar Power (Watts)',
          viewWindowMode: 'explicit',
          viewWindow:{
          	min:0,
          },
          gridlines:{
          	count:11,
          }
        },
        legend: {
        	position: 'none',
        },
        
		chartArea:{
        	left: 50,
        	top: 30,
        	width: 650,
        	height: 420,
        }
    }   	
	var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
      	chart.draw(data, options);
        setInterval(function() {
          $.ajax({
            url: "php/query_sys.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {
            	var PV_V = Number(response['PV_V']);
            	var PV_C = Number(response['PV_C']);
            	var Local_Time = Number(response['Local_Time']);
            	if (PV_V<0) { PV_V= 0;
              	}
              	if (PV_C<0) { PV_C= 0;
              	}
              	
              	var Power = PV_V*PV_C;
              	var Time = Local_Time;
              	
              	data.addRows([[Time, Power]]);
              	
              	if (Time>=0 && Time<0.02){
              		i = data.getNumberOfRows();
              		data.removeRows(0, i);
              	}
              	
				chart.draw(data, options);           
				document.getElementById('chart_div');
      		}
      	  })
      	}, 1000);
};