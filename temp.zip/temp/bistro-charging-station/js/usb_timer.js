$.ajax({
    url: "php/query_usb.php",
    dataType: 'json',
    type: "GET",
    success: function (response) {
        for (var i = 1; i < 9; i++) {
            var usbindex = 'USB' + i.toString()
            console.log('usbindex:' + usbindex)
            $usb = response[usbindex];
            $usbvalue=$usb.toString() + 'w';
            //console.log($usb);
            $divname = '#usb' + i.toString();
            //console.log($divname + $usb);
            $($divname).html($usbvalue);
        }
    }
});

$(document).ready(function () {
    refreshTable();
    
});

function refreshTable() {
    setTimeout(function () {
        $.ajax({
            url: "php/query_usb.php",
            dataType: 'json',
            type: "GET",
            success: function (response) {
                for (var i = 1; i < 9; i++) {
                    var usbindex = 'USB' + i.toString()
                    //console.log('usbindex:' + usbindex)
                    $usb = response[usbindex];
                    $usbvalue=$usb.toString() + 'w';
                    console.log($usb);
                    $divname = '#usb' + i.toString() ;
                    console.log($divname + $usb);
                    $($divname).html($usbvalue);
                
                }
            }
        });
        refreshTable();
    }, 1000);// update time
}

