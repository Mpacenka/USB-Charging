<?php
  require_once 'login.php';
 $conn = new mysqli($hn, $un, $pw, $db);
 if ($conn->connect_error) die($conn->connect_error);
 $today = date("Y-m-d", time());
 $query = "SELECT * FROM SYS WHERE Data_Day = '$today' ";
 //$query = "SELECT * FROM SYS_Single";
 $result = $conn->query($query);
 if (!$result) die($conn->error);
 $rows = $result->num_rows;
 $tabledata = array();

 $tabledata = $result->fetch_all(MYSQLI_NUM);

 echo json_encode($tabledata);

 $result->close();
 $conn->close();
?>