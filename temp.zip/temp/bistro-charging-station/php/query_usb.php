<?php
  require_once 'login.php';
 $conn = new mysqli($hn, $un, $pw, $db);
 if ($conn->connect_error) die($conn->connect_error);
 $query = "SELECT * FROM USB_Single";
 $result = $conn->query($query);
 if (!$result) die($conn->error);
 //$rows = $result->num_rows;
// $tabledata = array();

    $result->data_seek(0);
    $row = $result->fetch_array(MYSQLI_ASSOC);
    $tabledata = $row;
 
 echo json_encode($tabledata);

 $result->close();
 $conn->close();
?>