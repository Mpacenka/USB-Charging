<?php

namespace Users\megan\Documents\Clark\Microgrid Lab\htcdocs\php

class Pages {
  Public function render()
  {
    return 'Hello World';
  }
  
  public function returnTrue()
  {
  return true;
  }
  
  public function returnArray()
  {
  return ['Hello', 'World', 'this', 'is', 'an', 'array']
  }
}
?>