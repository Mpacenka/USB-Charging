<?php // login.php
  $hn = '140.232.220.200';
  $db = 'Agosta_Micgrid';
  $un = 'admin';
  $pw = 'energy!';
?>
